import { useState } from "react";
import AdminIcon, { type IconName } from "./AdminIcon";
import type { AdminView } from "./adminNavigation";
import {
  recordDate,
  recordTime,
  useRecords,
  type RecordState,
} from "./adminRecords";

function DataState({
  state,
  empty = "No records yet.",
}: {
  state: RecordState;
  empty?: string;
}) {
  return state.loading ? (
    <p className="v2-empty" role="status">
      Loading records…
    </p>
  ) : state.error ? (
    <p className="control-error" role="alert">
      {state.error}
    </p>
  ) : !state.rows.length ? (
    <p className="v2-empty">{empty}</p>
  ) : null;
}
function Badge({ value }: { value: unknown }) {
  const status = String(value || "unknown");
  return (
    <span
      className={`control-badge ${status === "approved" ? "" : status === "rejected" ? "rose" : "gold"}`}
    >
      {status.replaceAll("_", " ")}
    </span>
  );
}
export default function AdminDashboard({
  name,
  members,
  chats,
  activity,
  onOpen,
}: {
  name: string;
  members: RecordState;
  chats: RecordState;
  activity: RecordState;
  onOpen: (view: AdminView) => void;
}) {
  const broadcasts = useRecords("broadcasts");
  const [period, setPeriod] = useState(6);
  const now = new Date();
  const approved = members.rows.filter((row) => row.status === "approved");
  const pending = members.rows.filter((row) =>
    ["pending", "new", "under_review"].includes(String(row.status)),
  );
  const published = broadcasts.rows.filter(
    (row) =>
      row.published === true &&
      (!row.expiresAt || recordTime(row.expiresAt) > now.getTime()),
  );
  const metrics: {
    label: string;
    value: number;
    state: RecordState;
    icon: IconName;
    view: AdminView;
    note: string;
    color: string;
  }[] = [
    {
      label: "Approved members",
      value: approved.length,
      state: members,
      icon: "members",
      view: "members",
      note: "Your growing community",
      color: "green",
    },
    {
      label: "Awaiting review",
      value: pending.length,
      state: members,
      icon: "applications",
      view: "membershipApplications",
      note: "Applications needing a decision",
      color: "orange",
    },
    {
      label: "Member conversations",
      value: chats.rows.length,
      state: chats,
      icon: "chat",
      view: "memberChats",
      note: "Stay connected with members",
      color: "blue",
    },
    {
      label: "Active broadcasts",
      value: published.length,
      state: broadcasts,
      icon: "broadcast",
      view: "broadcasts",
      note: "Published and unexpired notices",
      color: "purple",
    },
  ];
  const months = Array.from({ length: period }, (_, index) => {
    const start = new Date(
      now.getFullYear(),
      now.getMonth() - period + 1 + index,
      1,
    );
    const end = new Date(start.getFullYear(), start.getMonth() + 1, 1);
    return {
      label: start.toLocaleDateString("en-NG", { month: "short" }),
      count: approved.filter(
        (row) =>
          recordTime(row.reviewedAt) >= start.getTime() &&
          recordTime(row.reviewedAt) < end.getTime(),
      ).length,
    };
  });
  const max = Math.max(
    2,
    Math.ceil(Math.max(...months.map((month) => month.count)) / 2) * 2,
  );
  const points = months.map(
    (month, index) =>
      `${45 + (index * 520) / (period - 1)},${170 - (month.count / max) * 130}`,
  );
  const total = members.rows.length;
  const statusGroups = [
    { label: "Approved", count: approved.length, color: "#187654" },
    { label: "Awaiting review", count: pending.length, color: "#e9a245" },
    {
      label: "Rejected",
      count: members.rows.filter((row) => row.status === "rejected").length,
      color: "#d98175",
    },
    {
      label: "Other",
      count: members.rows.filter(
        (row) =>
          !["approved", "pending", "new", "under_review", "rejected"].includes(
            String(row.status),
          ),
      ).length,
      color: "#a3b3aa",
    },
  ];
  let offset = 0;
  const segments = statusGroups.map((group) => {
    const start = offset;
    offset += total ? (group.count / total) * 100 : 0;
    return `${group.color} ${start}% ${offset}%`;
  });
  const recent = [...members.rows]
    .sort((a, b) => recordTime(b.createdAt) - recordTime(a.createdAt))
    .slice(0, 5);
  const recentChats = [...chats.rows]
    .sort((a, b) => recordTime(b.updatedAt) - recordTime(a.updatedAt))
    .slice(0, 3);
  const events = [
    ...activity.rows.map((row) => ({
      id: `activity-${row.id}`,
      title: String(row.action || "Broadcast activity"),
      detail: String(row.title || "Broadcast"),
      date: row.createdAt,
      view: "activity" as AdminView,
      icon: "broadcast" as IconName,
    })),
    ...members.rows.map((row) => ({
      id: `application-${row.id}`,
      title: row.reviewedAt
        ? `Membership ${String(row.status).replaceAll("_", " ")}`
        : "Application received",
      detail: String(row.fullName || "Member application"),
      date: row.reviewedAt || row.createdAt,
      view: "membershipApplications" as AdminView,
      icon: "applications" as IconName,
    })),
    ...chats.rows.map((row) => ({
      id: `chat-${row.id}`,
      title: "Conversation updated",
      detail: String(row.memberName || "ASBESOC member"),
      date: row.updatedAt,
      view: "memberChats" as AdminView,
      icon: "chat" as IconName,
    })),
  ]
    .filter((row) => recordTime(row.date))
    .sort((a, b) => recordTime(b.date) - recordTime(a.date))
    .slice(0, 4);
  return (
    <div className="v2-dashboard">
      <section className="v2-welcome">
        <div className="v2-welcome-copy">
          <p className="v2-eyebrow">PEOPLE. PURPOSE. PROGRESS.</p>
          <h2>
            Welcome back, {name}
            <span>.</span>
          </h2>
          <p>
            Every connection brings us closer to a better society.
            <br />
            Here’s what’s happening across ASBESOC.
          </p>
          <button onClick={() => onOpen("membershipApplications")}>
            Review applications
            <AdminIcon name="arrow" size={17} />
          </button>
        </div>
        <div className="v2-welcome-art" aria-hidden="true">
          <div className="v2-orbit orbit-one" />
          <div className="v2-orbit orbit-two" />
          <div className="v2-art-center">
            <AdminIcon name="members" size={54} />
          </div>
          <span className="v2-art-chip chip-one">
            <AdminIcon name="support" />
            Stronger together
          </span>
          <span className="v2-art-chip chip-two">
            <AdminIcon name="check" size={17} />
            Making an impact
          </span>
        </div>
      </section>
      <div className="v2-kpis">
        {metrics.map((metric) => (
          <button
            key={metric.label}
            className="v2-kpi"
            onClick={() => onOpen(metric.view)}
          >
            <span className={`v2-kpi-icon ${metric.color}`}>
              <AdminIcon name={metric.icon} />
            </span>
            <AdminIcon name="arrow" size={15} />
            <p>{metric.label}</p>
            <strong>
              {metric.state.loading
                ? "…"
                : metric.state.error
                  ? "—"
                  : metric.value.toLocaleString()}
            </strong>
            <small>
              {metric.state.error
                ? "Unavailable · open section"
                : metric.state.loading
                  ? "Loading live records"
                  : metric.note}
            </small>
          </button>
        ))}
      </div>
      <div className="v2-chart-grid">
        <section className="control-panel">
          <div className="v2-panel-heading">
            <div>
              <h2>Membership growth</h2>
              <p>New approvals by month</p>
            </div>
            <select
              aria-label="Membership chart period"
              value={period}
              onChange={(event) => setPeriod(Number(event.target.value))}
            >
              <option value={6}>Last 6 months</option>
              <option value={12}>Last 12 months</option>
            </select>
          </div>
          <DataState
            state={members}
            empty="Membership growth will appear when applications arrive."
          />
          {!members.loading && !members.error && total > 0 && (
            <>
              <div className="v2-chart-total">
                <strong>
                  {months.reduce((sum, month) => sum + month.count, 0)}
                </strong>
                <span>dated approvals in this period</span>
              </div>
              <svg
                className="v2-line-chart"
                viewBox="0 0 600 210"
                role="img"
                aria-label={`Monthly membership approvals: ${months.map((month) => `${month.label}: ${month.count}`).join(", ")}`}
              >
                <defs>
                  <linearGradient id="growth-fill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#51a883" stopOpacity=".22" />
                    <stop offset="100%" stopColor="#51a883" stopOpacity="0" />
                  </linearGradient>
                </defs>
                {[0, 0.5, 1].map((fraction) => (
                  <g key={fraction}>
                    <line
                      x1="45"
                      x2="565"
                      y1={170 - 130 * fraction}
                      y2={170 - 130 * fraction}
                      stroke="#e9eeea"
                      strokeDasharray="4 5"
                    />
                    <text x="10" y={175 - 130 * fraction}>
                      {Math.round(max * fraction)}
                    </text>
                  </g>
                ))}
                <path
                  d={`M${points.join(" L")} L565,170 L45,170 Z`}
                  fill="url(#growth-fill)"
                />
                <polyline
                  points={points.join(" ")}
                  fill="none"
                  stroke="#20805b"
                  strokeWidth="3"
                />
                {months.map((month, index) => (
                  <g key={index}>
                    <circle
                      cx={45 + (index * 520) / (period - 1)}
                      cy={170 - (month.count / max) * 130}
                      r="4"
                      fill="white"
                      stroke="#20805b"
                      strokeWidth="2"
                    >
                      <title>
                        {month.label}: {month.count} approvals
                      </title>
                    </circle>
                    <text
                      textAnchor="middle"
                      x={45 + (index * 520) / (period - 1)}
                      y="202"
                    >
                      {month.label}
                    </text>
                  </g>
                ))}
              </svg>
              {approved.some((row) => !recordTime(row.reviewedAt)) && (
                <p className="v2-chart-note">
                  Approvals without a review date are excluded from this chart.
                </p>
              )}
            </>
          )}
        </section>
        <section className="control-panel">
          <div className="v2-panel-heading">
            <div>
              <h2>Application status</h2>
              <p>All membership applications</p>
            </div>
            <AdminIcon name="applications" />
          </div>
          <DataState
            state={members}
            empty="No applications yet. Your review pipeline will appear here."
          />
          {!members.loading && !members.error && total > 0 && (
            <>
              <div
                className="v2-donut"
                style={{ background: `conic-gradient(${segments.join(",")})` }}
                role="img"
                aria-label={statusGroups
                  .map((group) => `${group.label}: ${group.count}`)
                  .join(", ")}
              >
                <div>
                  <strong>{total}</strong>
                  <small>Total applications</small>
                </div>
              </div>
              <div className="v2-legend">
                {statusGroups
                  .filter((group) => group.label !== "Other" || group.count)
                  .map((group) => (
                    <div key={group.label}>
                      <i style={{ background: group.color }} />
                      <span>{group.label}</span>
                      <b>{group.count}</b>
                    </div>
                  ))}
              </div>
            </>
          )}
        </section>
      </div>
      <section className="v2-quick-actions">
        <div>
          <h2>Make your next move</h2>
          <p>A little action. A lasting impact.</p>
        </div>
        {(
          [
            {
              view: "broadcasts",
              label: "Create broadcast",
              icon: "broadcast",
            },
            {
              view: "memberFeed",
              label: "Post announcement",
              icon: "announcement",
            },
            { view: "trainings", label: "Add opportunity", icon: "training" },
            { view: "gallery", label: "Manage media", icon: "media" },
          ] as { view: AdminView; label: string; icon: IconName }[]
        ).map((action) => (
          <button key={action.view} onClick={() => onOpen(action.view)}>
            <AdminIcon name={action.icon} />
            <span>{action.label}</span>
            <AdminIcon name="arrow" size={14} />
          </button>
        ))}
      </section>
      <div className="v2-record-grid">
        <section className="control-panel v2-recent-applications">
          <div className="v2-panel-heading">
            <div>
              <h2>Recent applications</h2>
              <p>The latest people joining your community</p>
            </div>
            <button
              className="v2-text-link"
              onClick={() => onOpen("membershipApplications")}
            >
              View all <AdminIcon name="arrow" size={14} />
            </button>
          </div>
          <DataState state={members} />
          {!members.loading && !members.error && recent.length > 0 && (
            <div className="control-table-wrap">
              <table className="control-table">
                <thead>
                  <tr>
                    <th>Applicant</th>
                    <th>Received</th>
                    <th>Status</th>
                    <th>
                      <span className="sr-only">Action</span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {recent.map((row) => (
                    <tr key={row.id}>
                      <td>
                        <div className="v2-person">
                          <span className="v2-avatar soft">
                            {String(row.fullName || "M")
                              .slice(0, 2)
                              .toUpperCase()}
                          </span>
                          <span>
                            <b>
                              {String(row.fullName || "Member application")}
                            </b>
                            <small>
                              {String(row.email || "Email not provided")}
                            </small>
                          </span>
                        </div>
                      </td>
                      <td>{recordDate(row.createdAt)}</td>
                      <td>
                        <Badge value={row.status} />
                      </td>
                      <td>
                        <button
                          className="v2-icon-button"
                          aria-label={`Open applications to review ${String(row.fullName || "applicant")}`}
                          onClick={() => onOpen("membershipApplications")}
                        >
                          <AdminIcon name="arrow" size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
        <section className="control-panel">
          <div className="v2-panel-heading">
            <div>
              <h2>Member chats</h2>
              <p>Keep the conversation going</p>
            </div>
            <button
              className="v2-text-link"
              onClick={() => onOpen("memberChats")}
            >
              Open inbox
              <AdminIcon name="arrow" size={14} />
            </button>
          </div>
          <DataState
            state={chats}
            empty="No conversations yet. Member messages will appear here."
          />
          {recentChats.map((row) => (
            <button
              className="v2-chat-preview"
              key={row.id}
              onClick={() => onOpen("memberChats")}
            >
              <span className="v2-avatar soft">
                <AdminIcon name="chat" size={18} />
              </span>
              <span>
                <b>{String(row.memberName || "ASBESOC member")}</b>
                <small>
                  {String(row.memberEmail || "Private conversation")}
                </small>
                <time>Updated {recordDate(row.updatedAt)}</time>
              </span>
              <AdminIcon name="arrow" size={15} />
            </button>
          ))}
        </section>
      </div>
      <section className="control-panel">
        <div className="v2-panel-heading">
          <div>
            <h2>Recent activity</h2>
            <p>Latest recorded membership, chat and broadcast changes</p>
          </div>
          <button className="v2-text-link" onClick={() => onOpen("activity")}>
            All activity <AdminIcon name="arrow" size={14} />
          </button>
        </div>
        {[members, chats, activity].some((state) => state.error) && (
          <p className="control-error" role="alert">
            Some activity sources are unavailable. Showing available records.
          </p>
        )}
        {[members, chats, activity].some((state) => state.loading) && (
          <p role="status" className="v2-empty">
            Loading activity…
          </p>
        )}
        <div className="v2-timeline">
          {events.map((event) => (
            <button key={event.id} onClick={() => onOpen(event.view)}>
              <span className="v2-timeline-icon">
                <AdminIcon name={event.icon} size={16} />
              </span>
              <span>
                <b>{event.title}</b>
                <small>{event.detail}</small>
                <time>{recordDate(event.date)}</time>
              </span>
            </button>
          ))}
        </div>
        {![members, chats, activity].some(
          (state) => state.loading || state.error,
        ) &&
          !events.length && (
            <p className="v2-empty">No recorded activity yet.</p>
          )}
      </section>
    </div>
  );
}
